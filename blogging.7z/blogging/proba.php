<?php

$database= "localhost";
$user="root";
$password="";
$dbname="bridge";

$connection = mysqli_connect($database,$user,$password,$dbname);

if(!$connection){
    mysqli_error($connection);
    die();
}

$user = "urban";

$sql = "SELECT * FROM members WHERE username = '$user';";
$result = mysqli_query($connection, $sql) or die(mysqli_error($connection));

if($record = mysqli_fetch_array($result)>0)
{
    while($record = mysqli_fetch_array($result))
    {
        $com = $record['c_name'];
        echo "$com <br>";
    }
}
