<?php
include "database.php";
$sql = "SELECT * from topics";
$result = mysqli_query($connection, $sql) or (mysqli_error($connection));

if(mysqli_fetch_array($result)>0) {
    while ($record = mysqli_fetch_array($result, MYSQLI_ASSOC))
    {
        $_SESSION['title'] = $record['title'];
        $_SESSION['cover'] = $record['cover'];
        $_SESSION['content'] = $record['content'];
        $_SESSION['tag'] = $record['tag'];

        ?>

        <div class="col-md-4 col-sm-6">
        <div class="single-blog-post">
            <div class="post-img">
                <a href="#"><img src="img/blog/<?php echo $_SESSION['cover'] ?>" alt="Popular Post"/></a>
                <a href="#" class="post-tag"><?php echo $_SESSION['tag'] ?></a>
                <div class="post-info">
                    <p>
                        <span class="post-date"><a href="#">July 10, 2015</a></span>
                        <span class="post-comments"><a href="#">3 comments</a></span>
                        <span class="post-social-links">
                            <a href="#" data-toggle="tooltip" data-placement="bottom" title="Likes"><i
                                    class="fa fa-heart"></i></a>
                            <a href="#" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i
                                    class="fa fa-facebook"></i></a>
                            <a href="#" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i
                                    class="fa fa-twitter"></i></a>
                            <a href="#" data-toggle="tooltip" data-placement="bottom" title="Google+"><i
                                    class="fa fa-google-plus"></i></a>
                            <a href="#" data-toggle="tooltip" data-placement="bottom" title="Pinterest"><i
                                    class="fa fa-pinterest"></i></a>
                        </span>
                    </p>
                </div>
            </div>
            <div class="post-content">
                <h6 class="post-title"><a href="#"><?php echo $_SESSION['title'] ?></a></h6>
                <p class="post-short-desc"> <?php echo $_SESSION['content'] ?> </p>
                <a href="#" class="continue-link">Continue Reading...</a>
            </div>
        </div><!-- /.single-blog-post -->
        </div>

        <?php
    }
}