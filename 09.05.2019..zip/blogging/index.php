<!DOCTYPE html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Bridge - Homepage</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

		<!-- favicon
		============================================ -->		
        <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
		
		<!-- Google Fonts
		============================================ -->		
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css'>
        <link href="https://fonts.googleapis.com/css?family=Fugaz+One" rel="stylesheet">


        <!-- Bootstrap CSS
        ============================================ -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- font-awesome CSS
		============================================ -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
		<!-- owl.carousel CSS
		============================================ -->
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/owl.theme.css">
        <link rel="stylesheet" href="css/owl.transitions.css">
		<!-- meanmenu CSS
		============================================ -->
        <link rel="stylesheet" href="css/meanmenu.css">
		<!-- normalize CSS
		============================================ -->
        <link rel="stylesheet" href="css/normalize.css">
		<!-- main CSS
		============================================ -->
        <link rel="stylesheet" href="css/main.css">
		<!-- style CSS
		============================================ -->
        <link rel="stylesheet" href="style.css">
		<!-- responsive CSS
		============================================ -->
        <link rel="stylesheet" href="css/responsive.css">
		<!-- modernizr JS
		============================================ -->		
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body class="home-2">
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <!-- header-area start -->
		<header id="header" class="header-area">
			<div class="header-top">
				<div class="container">
					<div class="row">
						<div class="col-md-6 col-sm-6 col-xs-6">

						</div>
						<div class="col-md-6 col-sm-6 col-xs-6">
							<div class="header-top-right fix">
								<div class="header-links">
									<ul>
                                        <?php
                                        session_start();

                                        $logged = false;
                                        if (isset($_SESSION['logged']))
                                        $logged = $_SESSION['logged'];

                                        if ($logged) {
                                        $abs = $_SESSION['abs'];

                                        ?>
                                        <form method="post" action="logout.php">

                                            <li><a href="profile.php"><?php echo $_SESSION['username']; ?></a></li>
                                            <li><input type="submit" value="Sign out" name="logout"></li>

                                        </form>

                                        <?php

 } else {
                                            header("Location: login.php");
                                        }
                                        ?>
									</ul>
								</div>
								<div class="header-search">
									<form action="#" method="post">
										<button type="button" class="search-toggler"><i class="fa fa-search"></i></button>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div><!-- /.header-top -->
			<div class="header-bottom">
				<div class="container">
					<div class="row">
						<div class="col-md-3">
							<div class="logo">
								<a href="index.php"><img src="img/logo/logo.png" alt="Logo" /></a>
							</div>
						</div>
						<div class="col-md-9">
							<div class="main-menu">
								<nav>
								  <ul class="main-nav navbar-right">
									<li class="active"><a href="#">Home</a></li>
									<li><a href="communitys.php">Community</a></li>
									<li><a href="blog-column-3.php">Topics</a></li>
									<li><a href="profile.php">Profile</a></li>
									<li><a href="contact-us.php">Contact Us</a></li>
								  </ul>
								</nav>
							</div><!-- /.main-menu -->
						</div>
					</div>
				</div>
				<!-- mobile-menu-area start -->
				<div class="mobile-menu-area">
					<div class="container">
						<div class="row">
							<div class="col-md-12">
								<nav id="dropdown">
									<ul>
										<li><a href="#">Home</a></li>
										<li><a href="communitys.php">Community</a></li>
										<li><a href="blog-column-3.php">Topics</a></li>
										<li><a href="profile.php">Profil</a></li>
										<li><a href="contact-us.php">contact us</a></li>
									</ul>
								</nav>
							</div>
						</div>
					</div>
				</div>
				<!-- mobile-menu-area end -->
			</div><!-- /.header-bottom -->
		</header>
        <!-- header-area end -->

		<!-- search-area start -->
		<div class="search-area">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="search-form">
							<span class="search-close"></span>
							<form action="#" method="post">
								<input type="text" placeholder="Search here..."/>
								<button type="submit" class="search-btn"><i class="fa fa-search"></i></button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- search-area end -->

		<!-- heading-area start -->
		<div id="blog-heading" class="heading-area">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<h2>Drina</h2>
					</div>
				</div>
			</div>
		</div>
		<!-- heading-area end -->
		
		<!-- main-content-area start -->
		<div id="main-content" class="main-content-area">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-sm-12">
						<div class="popular-posts-area">
							<h2 class="section-title">popular posts</h2>
							<div class="row">
								<div class="col-md-6 col-sm-6">
									<div class="single-popular-post">
										<div class="post-img">
											<a href="#"><img src="img/blog/5.jpg" alt="Popular Post" /></a>
											<a href="#" class="post-tag">travel</a>
											<div class="post-info">
												<p>
													<span class="post-date"><a href="#">July 10, 2015</a></span>
													<span class="post-comments"><a href="#">3 comments</a></span>
													<span class="post-social-links">
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Likes"><i class="fa fa-heart"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Google+"><i class="fa fa-google-plus"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Pinterest"><i class="fa fa-pinterest"></i></a>
													</span>
												</p>
											</div>
										</div>
										<div class="post-content">
											<h6 class="post-title"><a href="#">Savior of Hustler</a></h6>
											<p class="post-short-desc">Lorem ipsum dolor sit amet, consegectetur 
											adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore 
											magna aliqua. Ut enim ad minim veniam, nostrud exercitation ullamco 
											laboris nisi...</p>
											<a href="#" class="continue-link">Continue Reading...</a>
										</div>
									</div><!-- /.single-popular-post -->
								</div>
								<div class="col-md-6 col-sm-6">
									<div class="single-popular-post">
										<div class="post-img">
											<a href="#"><img src="img/blog/2.jpg" alt="Popular Post" /></a>
											<a href="#" class="post-tag">photography</a>
											<div class="post-info">
												<p>
													<span class="post-date"><a href="#">July 10, 2015</a></span>
													<span class="post-comments"><a href="#">3 comments</a></span>
													<span class="post-social-links">
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Likes"><i class="fa fa-heart"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Google+"><i class="fa fa-google-plus"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Pinterest"><i class="fa fa-pinterest"></i></a>
													</span>
												</p>
											</div>
										</div>
										<div class="post-content">
											<h6 class="post-title"><a href="#">Summer Vacation Memories</a></h6>
											<p class="post-short-desc">Lorem ipsum dolor sit amet, consegectetur 
											adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore 
											magna aliqua. Ut enim ad minim veniam, nostrud exercitation ullamco 
											laboris nisi...</p>
											<a href="#" class="continue-link">Continue Reading...</a>
										</div>
									</div><!-- /.single-popular-post -->
								</div>
								<div class="col-md-6 col-sm-6">
									<div class="single-popular-post">
										<div class="post-img">
											<a href="#"><img src="img/blog/6.jpg" alt="Popular Post" /></a>
											<a href="#" class="post-tag">lifestyle</a>
											<div class="post-info">
												<p>
													<span class="post-date"><a href="#">July 10, 2015</a></span>
													<span class="post-comments"><a href="#">3 comments</a></span>
													<span class="post-social-links">
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Likes"><i class="fa fa-heart"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Google+"><i class="fa fa-google-plus"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Pinterest"><i class="fa fa-pinterest"></i></a>
													</span>
												</p>
											</div>
										</div>
										<div class="post-content">
											<h6 class="post-title"><a href="#">Lover in the Petals</a></h6>
											<p class="post-short-desc">Lorem ipsum dolor sit amet, consegectetur 
											adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore 
											magna aliqua. Ut enim ad minim veniam, nostrud exercitation ullamco 
											laboris nisi...</p>
											<a href="#" class="continue-link">Continue Reading...</a>
										</div>
									</div><!-- /.single-popular-post -->
								</div>
								<div class="col-md-6 col-sm-6">
									<div class="single-popular-post">
										<div class="post-img">
											<a href="#"><img src="img/blog/4.jpg" alt="Popular Post" /></a>
											<a href="#" class="post-tag">photography</a>
											<div class="post-info">
												<p>
													<span class="post-date"><a href="#">July 10, 2015</a></span>
													<span class="post-comments"><a href="#">3 comments</a></span>
													<span class="post-social-links">
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Likes"><i class="fa fa-heart"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Google+"><i class="fa fa-google-plus"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Pinterest"><i class="fa fa-pinterest"></i></a>
													</span>
												</p>
											</div>
										</div>
										<div class="post-content">
											<h6 class="post-title"><a href="#">The Waves of the Butterfly</a></h6>
											<p class="post-short-desc">Lorem ipsum dolor sit amet, consegectetur 
											adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore 
											magna aliqua. Ut enim ad minim veniam, nostrud exercitation ullamco 
											laboris nisi...</p>
											<a href="#" class="continue-link">Continue Reading...</a>
										</div>
									</div><!-- /.single-popular-post -->
								</div>
							</div>
						</div><!-- /.popular-posts-area -->
						
						<!-- latest-reviews-area start -->
						<div id="latest-reviews" class="latest-reviews-area">
							<h2 class="section-title">latest reviews</h2>
							<div class="row">
								<div class="col-md-12">
									<div class="single-review">
										<div class="post-img">
											<a href="#"><img src="img/reviews/1.jpg" alt="Review Image" /></a>
											<a href="#" class="post-tag">photography</a>
											<div class="post-info">
												<p>
													<span class="post-date"><a href="#">July 10, 2015</a></span>
													<span class="post-comments"><a href="#">3 comments</a></span>
													<span class="post-social-links">
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Likes"><i class="fa fa-heart"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Google+"><i class="fa fa-google-plus"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Pinterest"><i class="fa fa-pinterest"></i></a>
													</span>
												</p>
											</div>
										</div>
										<div class="post-content">
											<h6 class="post-title"><a href="#">The Waves of the Butterfly</a></h6>
											<div class="post-rating">
												<ul>
													<li><a href="#"><i class="fa fa-star"></i></a></li>
													<li><a href="#"><i class="fa fa-star"></i></a></li>
													<li><a href="#"><i class="fa fa-star"></i></a></li>
													<li><a href="#"><i class="fa fa-star"></i></a></li>
													<li><a href="#"><i class="fa fa-star-half-o"></i></a></li>
												</ul>
											</div>
											<p class="post-short-desc">Lorem ipsum dolor sit amet, consegectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore  aliqua. Ut enim ad minim veniam, nostrud exercitation ullamco laboris nisi onsegectetur adipisicing elit, sed do eiusmod tempor incididunt labore et dolore magna aliqua. Ut enim ad minim veniam, nostrud exercitation ullamco laboris nisionsegectetur adipisicing elit, sed do eiusmod tempor incididunt</p>
											<a href="#" class="continue-link">Continue Reading...</a>
										</div>
									</div><!-- /.single-review -->
								</div>
								<div class="col-md-12">
									<div class="single-review">
										<div class="post-img">
											<a href="#"><img src="img/reviews/2.jpg" alt="Review Image" /></a>
											<a href="#" class="post-tag">photography</a>
											<div class="post-info">
												<p>
													<span class="post-date"><a href="#">July 10, 2015</a></span>
													<span class="post-comments"><a href="#">3 comments</a></span>
													<span class="post-social-links">
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Likes"><i class="fa fa-heart"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Google+"><i class="fa fa-google-plus"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Pinterest"><i class="fa fa-pinterest"></i></a>
													</span>
												</p>
											</div>
										</div>
										<div class="post-content">
											<h6 class="post-title"><a href="#">The Waves of the Butterfly</a></h6>
											<div class="post-rating">
												<ul>
													<li><a href="#"><i class="fa fa-star"></i></a></li>
													<li><a href="#"><i class="fa fa-star"></i></a></li>
													<li><a href="#"><i class="fa fa-star"></i></a></li>
													<li><a href="#"><i class="fa fa-star"></i></a></li>
													<li><a href="#"><i class="fa fa-star-half-o"></i></a></li>
												</ul>
											</div>
											<p class="post-short-desc">Lorem ipsum dolor sit amet, consegectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore  aliqua. Ut enim ad minim veniam, nostrud exercitation ullamco laboris nisi onsegectetur adipisicing elit, sed do eiusmod tempor incididunt labore et dolore magna aliqua. Ut enim ad minim veniam, nostrud exercitation ullamco laboris nisionsegectetur adipisicing elit, sed do eiusmod tempor incididunt</p>
											<a href="#" class="continue-link">Continue Reading...</a>
										</div>
									</div><!-- /.single-review -->
								</div>
							</div>
						</div>
						<!-- latest-reviews-area end -->
						
						<!-- featured-posts-area start -->
						<div id="featured-post" class="featured-posts-area">
							<h2 class="section-title">featured posts</h2>
							<div class="row">
								<div class="col-md-6 col-sm-6">
									<div class="single-featured-post">
										<div class="post-img">
											<a href="#"><img src="img/featured-posts/1.jpg" alt="Featured Post" /></a>
											<a href="#" class="post-tag">photography</a>
											<div class="post-info">
												<p>
													<span class="post-date"><a href="#">July 10, 2015</a></span>
													<span class="post-comments"><a href="#">3 comments</a></span>
													<span class="post-social-links">
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Likes"><i class="fa fa-heart"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Google+"><i class="fa fa-google-plus"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Pinterest"><i class="fa fa-pinterest"></i></a>
													</span>
												</p>
											</div>
										</div>
										<div class="post-content">
											<h6 class="post-title"><a href="#">Tale in the Lover</a></h6>
											<p class="post-short-desc">Lorem ipsum dolor sit amet, consegectetur 
											adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore 
											magna aliqua. Ut enim ad minim veniam, nostrud exercitation ullamco 
											laboris nisi...</p>
											<a href="#" class="continue-link">Continue Reading...</a>
										</div>
									</div><!-- /.single-featured-post -->
								</div>
								<div class="col-md-6 col-sm-6">
									<div class="single-featured-post">
										<div class="post-img">
											<a href="#"><img src="img/featured-posts/2.jpg" alt="Featured Post" /></a>
											<a href="#" class="post-tag">photography</a>
											<div class="post-info">
												<p>
													<span class="post-date"><a href="#">July 10, 2015</a></span>
													<span class="post-comments"><a href="#">3 comments</a></span>
													<span class="post-social-links">
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Likes"><i class="fa fa-heart"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Google+"><i class="fa fa-google-plus"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Pinterest"><i class="fa fa-pinterest"></i></a>
													</span>
												</p>
											</div>
										</div>
										<div class="post-content">
											<h6 class="post-title"><a href="#">The Cracked Secret</a></h6>
											<p class="post-short-desc">Lorem ipsum dolor sit amet, consegectetur 
											adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore 
											magna aliqua. Ut enim ad minim veniam, nostrud exercitation ullamco 
											laboris nisi...</p>
											<a href="#" class="continue-link">Continue Reading...</a>
										</div>
									</div><!-- /.single-featured-post -->
								</div>
								<div class="col-md-6 col-sm-6">
									<div class="single-featured-post">
										<div class="post-img">
											<a href="#"><img src="img/featured-posts/3.jpg" alt="Featured Post" /></a>
											<a href="#" class="post-tag">photography</a>
											<div class="post-info">
												<p>
													<span class="post-date"><a href="#">July 10, 2015</a></span>
													<span class="post-comments"><a href="#">3 comments</a></span>
													<span class="post-social-links">
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Likes"><i class="fa fa-heart"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Google+"><i class="fa fa-google-plus"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Pinterest"><i class="fa fa-pinterest"></i></a>
													</span>
												</p>
											</div>
										</div>
										<div class="post-content">
											<h6 class="post-title"><a href="#">Future in the Consort</a></h6>
											<p class="post-short-desc">Lorem ipsum dolor sit amet, consegectetur 
											adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore 
											magna aliqua. Ut enim ad minim veniam, nostrud exercitation ullamco 
											laboris nisi...</p>
											<a href="#" class="continue-link">Continue Reading...</a>
										</div>
									</div><!-- /.single-featured-post -->
								</div>
								<div class="col-md-6 col-sm-6">
									<div class="single-featured-post">
										<div class="post-img">
											<a href="#"><img src="img/featured-posts/4.jpg" alt="Featured Post" /></a>
											<a href="#" class="post-tag">photography</a>
											<div class="post-info">
												<p>
													<span class="post-date"><a href="#">July 10, 2015</a></span>
													<span class="post-comments"><a href="#">3 comments</a></span>
													<span class="post-social-links">
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Likes"><i class="fa fa-heart"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Facebook"><i class="fa fa-facebook"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Twitter"><i class="fa fa-twitter"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Google+"><i class="fa fa-google-plus"></i></a>
														<a href="#" data-toggle="tooltip" data-placement="bottom" title="Pinterest"><i class="fa fa-pinterest"></i></a>
													</span>
												</p>
											</div>
										</div>
										<div class="post-content">
											<h6 class="post-title"><a href="#">The Man of the Heat</a></h6>
											<p class="post-short-desc">Lorem ipsum dolor sit amet, consegectetur 
											adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore 
											magna aliqua. Ut enim ad minim veniam, nostrud exercitation ullamco 
											laboris nisi...</p>
											<a href="#" class="continue-link">Continue Reading...</a>
										</div>
									</div><!-- /.single-featured-post -->
								</div>
							</div>
						</div>
						<!-- featured-posts-area end -->
					</div>
					
					<div class="col-md-4 col-md-offset-0 col-sm-8 col-sm-offset-2">
						<div class="sidebar-area fix">
							<div class="single-sidebar-widget">
								<h6 class="widget-title">
                                    <?php
                                    echo $_SESSION['first'];
                                    echo " ";
                                    echo $_SESSION['last']
                                    ?>
                                </h6>
								<div class="sidebar-content about-me">
									<div class="my-photo">
										<img class="img-circle img-thumbnail " src="img/profile/<?php echo $_SESSION['picture']; ?>" alt="My Image" width="110px" height="110px">
									</div>
                                    <hr>
                                    <p><b>Name:</b> <?php echo $_SESSION['first']." ".$_SESSION['last']; ?></p>
                                    <p><b>Username:</b> <?php echo $_SESSION['username']; ?></p>
                                    <p><b>Status:</b> <?php if($abs){echo "<a href='admin-panel.php'>ABS</a>";} else{echo "Member";} ?></p>
                                    <p><b>Birthday:</b> <?php echo $_SESSION['birth']; ?></p>
                                    <p><b>Registred</b> <?php echo $_SESSION['reg']; ?></p>
                                    <hr><br>
                                    <form action="logout.php" method="post">
                                        <button class="btn btn-success" name="logout" type="submit">Sign out</button>
                                    </form>
								</div><!-- /.sidebar-content -->
                            </div><!-- /.single-sidebar-widget -->

							<div class="single-sidebar-widget">
								<h6 class="widget-title">follow me on</h6>
								<div class="sidebar-content">
									<div class="social-links-area">
										<div class="single-icon">
											<a href="#">
												<i class="fa fa-facebook"></i>
												<p>Facebook</p>
											</a>
										</div><!-- /.single-icon -->
										<div class="single-icon">
											<a href="#">
												<i class="fa fa-twitter"></i>
												<p>Twitter</p>
											</a>
										</div><!-- /.single-icon -->
										<div class="single-icon">
											<a href="#">
												<i class="fa fa-google-plus"></i>
												<p>Google Plus</p>
											</a>
										</div><!-- /.single-icon -->
										<div class="single-icon">
											<a href="#">
												<i class="fa fa-pinterest"></i>
												<p>Pinterest</p>
											</a>
										</div><!-- /.single-icon -->
										<div class="single-icon">
											<a href="#">
												<i class="fa fa-rss"></i>
												<p>RSS</p>
											</a>
										</div><!-- /.single-icon -->
										<div class="single-icon">
											<a href="#">
												<i class="fa fa-dribbble"></i>
												<p>Dribbble</p>
											</a>
										</div><!-- /.single-icon -->
										<div class="single-icon">
											<a href="#">
												<i class="fa fa-instagram"></i>
												<p>Instagram</p>
											</a>
										</div><!-- /.single-icon -->
										<div class="single-icon">
											<a href="#">
												<i class="fa fa-heart"></i>
												<p>Bloginlove</p>
											</a>
										</div><!-- /.single-icon -->
										<div class="single-icon">
											<a href="#">
												<i class="fa fa-envelope-o"></i>
												<p>Email</p>
											</a>
										</div><!-- /.single-icon -->
									</div><!-- /.social-links-area -->
								</div><!-- /.sidebar-content -->
							</div><!-- /.single-sidebar-widget -->
							<div class="single-sidebar-widget">
								<h6 class="widget-title">categories</h6>
								<div class="sidebar-content">
									<div class="categories-list">
										<ul>
											<li><a href="#"><span class="category">breaking</span><span class="number">(85)</span></a></li>
											<li><a href="#"><span class="category">business</span><span class="number">(75)</span></a></li>
											<li><a href="#"><span class="category">ecommerce</span><span class="number">(66)</span></a></li>
											<li><a href="#"><span class="category">fashion</span><span class="number">(63)</span></a></li>
											<li><a href="#"><span class="category">science</span><span class="number">(55)</span></a></li>
											<li><a href="#"><span class="category">girl</span><span class="number">(50)</span></a></li>
											<li><a href="#"><span class="category">technology</span><span class="number">(42)</span></a></li>
											<li><a href="#"><span class="category">shopping</span><span class="number">(29)</span></a></li>
											<li><a href="#"><span class="category">magazine</span><span class="number">(15)</span></a></li>
										</ul>
									</div>
								</div><!-- /.sidebar-content -->
							</div><!-- /.single-sidebar-widget -->
						</div><!-- /.sidebar-area -->
					</div>
				</div>
			</div>
		</div>
		<!-- main-content-area end -->
		
		<!-- footer-area start -->
		<footer id="footer" class="footer-area text-center">
			<div class="footer-logo">
				<a href="#"><img src="img/logo/footer-logo.png" alt="Footer Logo" /></a>
			</div>
		</footer>
		<!-- footer-area end -->
		
		<!-- jquery
		============================================ -->		
        <script src="js/vendor/jquery-1.11.3.min.js"></script>
		<!-- bootstrap JS
		============================================ -->		
        <script src="js/bootstrap.min.js"></script>		
		<!-- meanmenu JS
		============================================ -->		
        <script src="js/jquery.meanmenu.js"></script>
		<!-- owl.carousel JS
		============================================ -->		
        <script src="js/owl.carousel.min.js"></script>
		<!-- scrollUp JS
		============================================ -->		
        <script src="js/jquery.scrollUp.min.js"></script>
		<!-- plugins JS
		============================================ -->		
        <script src="js/plugins.js"></script>
		<!-- main JS
		============================================ -->		
        <script src="js/main.js"></script>
    </body>
</html>
