<?php
session_start();
include "database.php";

$username = '';

if(isset($_POST['name']))
    $username = $_POST['name'];

$sql = "SELECT * from users WHERE username = '$username'";
$result = mysqli_query($connection, $sql) or die(mysqli_error($connection));

if(mysqli_num_rows($result) > 0){
    while($record = mysqli_fetch_array($result)){

        echo "
        
                <div class=\"col-md-5\">
                <img src=\"img/profile/".$record['picture']."\" width=\"300px\" height=\"300px\" alt=\"profil picture\" class=\"img-circle img-responsive\">
                </div>
        
        ";

        echo"<div class=\"col-md-7\">";
        echo " <h1>".$record['first']." ".$record['last']."</h1>";
        echo "<hr>";
        echo "  <p><b>Name:</b>".$record['first']." ".$record['last']."</p>";
        echo " <p><b>Username:</b>".$record['username']."</p>";
        echo " <p><b>Communitys:</b></p>";
        echo " <p><b>Birthday: </b>".$record['birth']."</p>";
        echo " <p><b>Registred: </b>".$record['registered']."</p>";
        echo "  <br> ";
        echo "</div>";



    }
}
else
{
    echo"<div class=\"col-sm-3\"></div>";
    echo "
        
                <div class=\"col-md-2\">
                <img style='border: 2px; border-color: red;' src=\"img/profile/default.jpg\" width=\"150px\" height=\"150px\" alt=\"profil picture\" class=\"img-circle img-responsive\">
                </div>
        
        ";

    echo "<div class=\"col-sm-4\">";
    echo "<br><br>";
    echo " <h3 style='color: red;'>[ ! ] User not found !</h3>";
    echo "</div>";
}

