<?php
include "database.php";

//$post = $_SESSION['id_of_topic'];
$post = '';
if(isset($_POST['id_topic']))
    $post = mysqli_real_escape_string($connection, $_POST['id_topic']);

$sql = "SELECT * FROM topic_comments WHERE id_topics = '$post' ORDER BY id_comment DESC;";
$result = mysqli_query($connection, $sql) or die(mysqli_error($connection));

if(mysqli_num_rows($result)>0){
    while($record = mysqli_fetch_array($result)){
        $_SESSION['text'] = $record['text'];
        $_SESSION['datetime'] = $record['posted'];

        $id_user = $record['id_user'];
        $sqlName = "SELECT username from users where id_user = '$id_user';";
        $resultName = mysqli_query($connection, $sqlName) or die(mysqli_error($connection));
        $res2 = mysqli_fetch_array($resultName);
        $_SESSION['name'] = $res2['username'];

        $sqlPicture = "SELECT picture from users where id_user = '$id_user';";
        $resultPicture = mysqli_query($connection, $sqlPicture) or die(mysqli_error($connection));
        $res = mysqli_fetch_array($resultPicture);
        $_SESSION['photo'] = $res['picture'];
?>

    <div class="comment-box">
        <div class="comment-author">
            <img src="img/profile/<?php echo $_SESSION['photo']; ?>" alt="Comment Author" width="60px" height="60px">
        </div>
        <div class="comment-info">
            <p class="author-name"><a href="#"><?php echo $_SESSION['name']; ?></a></p>
            <span class="comment-date"><?php echo $_SESSION['datetime']; ?></span>
            <p><?php echo $_SESSION['text']; ?></p>
            <a href="#" class="reply-link" title="Reply">reply</a>
        </div>
        <hr>
    </div><!-- /.single-comment -->


<?php

    }
}



